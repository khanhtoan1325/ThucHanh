﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*
 * Cho chuỗi : 
	a= “
	tôi chăm học
	tôi chịu khó
	tôi đẹp zai
	“
	đếm từ tôi trong string a trên
 */




namespace thuchanh4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;
			string a = @"tôi chăm học
						 tôi chịu khó
						 tôi đẹp zai";
			string[] lst = a.Split(' ');
            int dem = 0;
            foreach (string s in lst)
            {
                //Console.WriteLine(s);s
                if ("tôi".Equals(s))
                    dem++;
            }
            Console.WriteLine(dem);
            Console.ReadKey();
        }
    }
}
