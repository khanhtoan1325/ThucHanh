﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

/*
 * Viết chương trình kiểm tra tính hợp lệ của mật khẩu: aaaaaAAAAAA1
  *  mật khẩu hợp lệ khi có ít nhất 6 ký tự chứa ít nhất 1 chữ cái ( chữ cái thường hoặc hoa đều được) 
  *chứa ít nhất 1 chữ số 
 2. cho người dùng nhập vào mật khẩu để login / so sánh, nếu đúng mở của, sai quá 5 lần khóa đăng nhập, thoát chương trình

 */
namespace thuchanh2
{
    internal class Program
    {

        static void Main(string[] args)
        {
            Console.WriteLine("Moi nhap vao co it nhat 6 ky tu , it nhat 1 chu cai, it nhat 1 chu so : ");
            string mk = Console.ReadLine();
            bool check = true;
            int demSo = 0, demKytu = 0; 
            while (check)
            {
                foreach (char c in mk)
                {
                    if (char .IsDigit(c))
                    {
                        demSo++;
                    }
                    else if (char .IsLetter(c))
                    {
                        demKytu++;
                    }
                }
                Console.WriteLine(demSo);
                Console.WriteLine(demKytu);
                if (demKytu * demSo !=0 && mk.Length >=6)
                {
                    check = false;
                }
                else
                {
                    Console.WriteLine("Nhap lai Mat Khau: ");
                    mk = Console.ReadLine();
                    check = true;
                }
            }

            string login;
            Console.WriteLine("Moi nhap vao mat khau dang nhap: ");
            login = Console.ReadLine();
            int demLogin = 0;
            while (true)
            {
                bool kp = mk.Equals(login);
                if (kp)
                {
                    Console.WriteLine("Dang nhap thanh cong: ");
                    break;
                }
                else
                {
                    demLogin++;
                    if (demLogin < 5)
                    {
                        Console.WriteLine("Moi nhap lai mat khau, nhap sao {0}/5 lan: ", demLogin);
                        login = Console.ReadLine();
                    }
                    else
                    {
                        Console.WriteLine("Ban da nhap mat khau qua 5 lan: ");
                        break ;
                    }
                }
            }





            Console.ReadKey ();

        }
    }
}
