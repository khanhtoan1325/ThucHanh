﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace Thuchanh14
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;
            Dictionary<string, int> dic = new Dictionary<string, int>() 
            { { "A", 1 }, { "B", 2 }, { "C", 3 }, { "D", 2 }, { "E", 1 }, { "F", 4 }, { "G", 2 }, { "H", 4 }, { "I", 1 }, { "J", 8 }, { "K", 5 }, { "L", 1 }, { "M", 3 }, { "N", 1 }, { "O", 1 }, { "P", 3 }, { "Q", 10 }, { "R", 1 }, { "S", 1 }, { "T", 1 }, { "U", 1 }, { "V", 4 }, { "W", 4 }, { "X", 8 }, { "Y", 4 }, { "Z", 10 } };
            // Duyệt Dic
            foreach (KeyValuePair<string,int> toan in dic)
            {
                Console.WriteLine(toan);
            }    
            // Tách chữ
            List<string> ds = new List<string>();
             ds = dic.Keys.ToList();
            Console.WriteLine("Chữ cái sau khi tách là: ");
            foreach (string key in ds)
            {
                Console.Write(key.PadRight(3));
            }
            Console.WriteLine();

            // Tách số
            List<int> ds2 = new List<int>();
            ds2 = dic.Values.ToList();
            Console.WriteLine("Số sau khi tách là: ");
            foreach (int so  in ds2)
            { 
                Console.Write(so.ToString().PadRight(3));
            }
            Console.WriteLine();

            // Tính tổng các chữ số
            int tong = ds2.Sum();
            Console.WriteLine("Tổng các chữ số là: "+tong);

            // Chuyển đổi chuỗi : "University of Technology and Education" sang số
            string s = "University of Technology and Education";
            string s2 = " ";
            foreach (char c in s)
            {
                s2 += char.ToUpper(c);
            }
            Console.WriteLine("Chuổi sau khi viết hoa là: ");
            Console.WriteLine(s2);

            // Chuyển đổi sang số
            string so1 = " ";
            foreach (char c in s2)
            {
                //Console.WriteLine(c);
                if (c ==' ')
                {
                    so1 += c;
                } 
                else
                {
                    so1 += dic[c.ToString()];
                }    
            }
            Console.WriteLine(so1);


            Console.ReadKey();

        }
    }
}
