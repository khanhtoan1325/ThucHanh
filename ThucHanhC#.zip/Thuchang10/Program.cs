﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Thuchang10
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;
            Console.WriteLine("Mời nhập vào số phần tử của danh sách: ");
            int n = int.Parse(Console.ReadLine());
            List<int> ds = new List<int>();
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine("Mời nhập vào phần tử thứ {0} của danh sách: ",i+1);
                ds.Add(int.Parse(Console.ReadLine()));
            }
            // Xuất list sau khi nhập 
            Console.WriteLine("List bạn vừa nhập là: ");
            foreach (int i in ds)
            {
                Console.Write(i+" ");
            }
            Console.WriteLine();
            // Tạo ra 1 list mới và bình phương các phần tử
            List<double> ds2 = new List<double>();
            foreach (double i in ds)
            {
                ds2.Add(Math.Pow(i, 2));
            }
            // Xuất danh sách 2
            Console.WriteLine("List 2 là: ");
            foreach (int i in ds2)
            {
                Console.Write(i + " ");
            }
            Console.WriteLine();
            // Xác định list có bao nhiêu phần tử lớn hơn 50
            int dem = 0;
            foreach (int i in ds2)
            {
                if (i > 50)
                    dem++;
            }
            Console.WriteLine("Có {0} lớn hơn 50 trong danh sách 2",dem);
            Console.ReadKey ();
        }
    }
}
