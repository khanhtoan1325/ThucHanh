﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Thuchanh9
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;
            Console.WriteLine("Mời nhập vào số phần tử:  ");
            int n = int.Parse(Console.ReadLine());

            Random r = new Random();
            List<int> ds = new List<int>();
            for (int i = 0; i < n; i++)
            {
                //Console.WriteLine(i);
                ds.Add(r.Next(1,101));
            }
            Console.WriteLine("Danh sách ngẫu nhiên vừa tạo ra là: ");
            foreach (int i in ds)
            {
                Console.Write(i+" ");
            } 
                
            Console.ReadKey();
        }
    }
}
