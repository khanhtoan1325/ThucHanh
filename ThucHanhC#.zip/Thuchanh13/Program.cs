﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Thuchanh13
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Khai báo dic 
            Dictionary<int,string> dic = new Dictionary<int,string>();
            // Khởi tạo và gán giá trị
            Dictionary<int, string> dic2 = new Dictionary<int, string>() { {1,"Toan" }, {2,"Top" } };


            Dictionary<string, int> dic3 = new Dictionary<string, int>() { { "20H11234", 0123456789 }, { "59H1999", 123456789 } };

            // Add 
            dic.Add(1, "Nguyễn Khánh Toàn");
            dic.Add(2, "Thịnh Ngu ");
            dic.Add(3, "Trình Ngu ");
            // Duyệt DIC
            foreach(KeyValuePair<int, string> kvp in dic)
            {
                Console.WriteLine(kvp);
                Console.WriteLine(kvp.Key);
                Console.WriteLine(kvp.Value);
            }    

            bool kq=dic .ContainsKey(5);
            Console.WriteLine("kq =" +kq);

            bool kq2 = dic.ContainsValue("Nguyễn Khánh Toàn");
            Console.WriteLine("kq2 ="+kq2);

            string name = dic[2];
            Console.WriteLine(name);

            dic.Remove(2);
            Console.WriteLine("Dic sau xoa là");
            foreach(KeyValuePair<int, string> kvp in dic)
            {
                Console.WriteLine(kvp);
            }
            // CHuyển sang list 
            Dictionary<string, int> dic4 = new Dictionary<string, int>() 
            { { "20H11234", 0123456789 }, { "59H1999", 123456789 } };
            List<int> ds = new List<int>();
            ds =dic4.Values.ToList();
            Console.WriteLine("Danh sách value là: ");
            foreach(int i in ds)
            {
                Console.WriteLine(i+" ");
            }    
            // CHuyển sanh list
            List<string> dsKey = new List<string>();
            dsKey= dic4.Keys.ToList();
            Console.WriteLine("Danh sách key là: ");
            foreach(string s in dsKey)
            {
                Console.WriteLine(s+" ");
            }    




            Console.ReadKey();


        }
    }
}
