﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Runtime.InteropServices;
using System.Runtime.Remoting.Channels;
using System.Runtime.Versioning;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace Thuchanh
{
    internal class Program
    {
        class Employee
        {
            public virtual void CalculatePay()
            {
                Console.WriteLine("Employee");
            }
        }
        class SaleEmployee : Employee
        {
            public override void CalculatePay()
            {
                base.CalculatePay();
                {
                    Console.WriteLine("SaleEmployee.Calculatepa y");
                }
            }
        }


        static void Main(string[] args)
        {
            Employee e = new Employee();
            SaleEmployee s = new SaleEmployee();

            e.CalculatePay();
            s.CalculatePay();
            e = new SaleEmployee();

            e.CalculatePay();
               
            Console.ReadKey (); 

        }   
    }
}

