﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
            /*Viết chương trình tách số và chữ từ chuỗi nhập vào thành 2 chuỗi : 	
                 * ví dụ nhập vào : abc123 sẽ tách và in ra thành 2 chuỗi abc và 123
             */



namespace thuchanh5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Moi nhap vao mot chuoi: ");
            string s = Console.ReadLine();
            string chuoi = "";
            string so = "";
            foreach (char c in s)
            {
                //Console.WriteLine(c);
                if (char.IsDigit(c))
                    so += c;
                else if (char.IsLetter(c))
                {
                    chuoi += c;
                }
            }
            Console.WriteLine(so);
            Console.WriteLine(chuoi);
            Console.ReadKey();
        }
    }
}
