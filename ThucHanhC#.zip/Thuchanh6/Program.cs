﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*
 * 1. Viết chương trình tạo ra 1 mảng 1 chiều bao gồm các phần tử số nguyên, có n phần tử ngẩu nhiên 
 * 2. Xuất các giá trị trong mảng 
 * 3. Đảo ngược mảng, và xuất mảng sau khi đảo ngược 
 * 4. Sắp xếp mảng tăng dần 
 * 5. Tính tổng các phần tử trong mảng 
 * 6. Cho người dùng nhập 1 số bất kỳ 
 * - Kiểm tra số đó có tồn tại trong mảng hay không 
 * - Nếu có xuất ra từ vị trí index của số đó trong mảng
 */
namespace Thuchanh6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;
            Console.WriteLine("Mời bạn nhập vào số phần tử của mảng: ");
            int n=int.Parse(Console.ReadLine());
            // Khai báo mảng 
            int[] Mang=new int[n];
            for (int i=0; i<n; i++)
            {
                Console.Write(Mang[i]+" ");
            }
            Console.WriteLine();

            // 1. Nhập giá trị ngẫu nhiên 
            Random r = new Random();
            Console.WriteLine("Mảng của bạn là: ");
            for (int i=0; i<n;i++)
            {
                Mang[i] = r.Next(101);
            }
            // Xuất mảng 
            for (int i=0; i<n;i++)
            {
                Console.Write(Mang[i]+" ");
            }
            Console.WriteLine();
            // Đảo ngược mảng
            Array.Reverse(Mang);
            Console.WriteLine("Mảng sau khi đảo ngược: ");
            for (int i=0; i<n;i++ )
            {
                Console.Write(Mang[i] + " ");
            }
            Console.WriteLine();
            // Sắp xếp mảng theo thứ tự tăng dần 
            Array.Sort(Mang);
            Console.WriteLine("Mảng sau khi sắp xếp là: ");
            for(int i=0; i<n;i++)
            {
                Console.Write(Mang[i] + " ");
            }
            Console.WriteLine();
            // Tính tổng các phần tử trong mảng 
            int tong = 0;
            foreach (int i in Mang)
            {
                tong += i;
            }
            Console.WriteLine("Tổng các phần tử của mảng là: "+tong);
            // Tìm kiếm, Cho người dùng nhập 1 số bất kỳ 
            Console.WriteLine("Mời bạn nhập vào số cần tìm: ");
            int so = int.Parse(Console.ReadLine()); // Ép kiểu nguyên
            int kq = Array.BinarySearch(Mang, so);
            if (kq ==  -1 ) // Nếu không tìm thấy 
            {
                Console.WriteLine("Không tìm thấy rồi thằng lồn: ");
            }    
            else // Nếu tìm thấy
            {
                Console.WriteLine("Tìm thấy số {0} ở vị trí {1} ", so,kq);
            }    

            // Tìm thông thường
            int demkq = 0;
            for (int i=0; i<n; i++ )
            {
                 if (Mang[i] == so)
                {
                    Console.WriteLine("Tìm thấy {0} tại vị trí {1}",so, i);
                    demkq++;
                }
               
                    
            }
            if (demkq == 0)
            {
                Console.WriteLine("Không tìm thấy rồi thằng lồn :)) ");
            }    
            Console.ReadKey();
        }
    }
}
