﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Thuchanh12
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;
            List<int> lst = new List<int>() { 1,2,3,4,5,6};
            List<int> ds2 = new List<int>();    
            ds2.AddRange(lst);
            Console.WriteLine("Danh sách 2 sau khi copy là: ");
            ds2.Remove(ds2.Max());
            ds2.Remove(ds2.Min());
            foreach (int i in ds2)
            {
                Console.Write(i+" ");
            }
            Console.WriteLine();
            Console.WriteLine("Phần tử lớn thứ 2 trong danh sách là: "+ds2.Max());
            Console.WriteLine("Phần tử nhỏ thứ 2 trong danh sách là "+ds2.Min());

            for (int i = 0; i < lst.Count(); i++)
            {
                if(lst[i] == ds2.Min())
                {
                    Console.WriteLine("Vị trí index của số nhỏ thứ 2 trong dãy là: "+i);
                }
                
            }

            for (int i = 0; i < lst.Count(); i++)
            {
                if (lst[i] == ds2.Max())
                {
                    Console.WriteLine("Vị trí index của số lớn thứ 2 trong dãy là: " + i);
                }

            }
            Console.ReadKey();

        }
    }
}
