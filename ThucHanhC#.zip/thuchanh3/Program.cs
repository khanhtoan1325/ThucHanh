﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace thuchanh3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string a = "abcdefghijklmnopqrstuvwxyz";
            string b = "zxcvbnmasdfghjklqwertyuiop";

            Console.WriteLine("Moi nhap vao chuoi can ma hoa: ");
            string chuoiInput = Console.ReadLine();
            string chuoiOutput = "";
            foreach (char c in chuoiInput)
            {
                Console.WriteLine(c);
                int indexkytu =  a .IndexOf(c);
                Console.WriteLine(indexkytu);
                Console.WriteLine(b[indexkytu]);
                chuoiOutput += b[indexkytu];
            }
            Console.WriteLine(chuoiOutput);

            Console.ReadKey();
        }
    }
}
