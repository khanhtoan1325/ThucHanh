﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Thuchanh8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<string> ds1 = new List<string>(); // Khởi tạo danh sách cách phần tử là string
            List<int> ds2 = new List<int>();    // Khởi tạo danh sách cách phần tử là số nguyên
            // Khởi tạo danh sách có sẵn một số phần tử , 
            List<int> ds3 = new List<int>() { 1, 2, 5,8,9 };
            foreach (int i in ds3)
            {
                Console.Write(i+" ");
            }

            // Phương thức Add
            List<int> ds4 = new List<int>() { 1, 2, 5 }; 
            ds4.Add(100);
            ds4.Add(200);
            Console.WriteLine("\nDanh sách 3 là: ");
            foreach (int i in ds4)
            {
                Console.Write(i+" ");
            }
            // Remove (Xóa phần tử đầu tiên nếu tìm thấy trong list)
            List<int> ds5 = new List<int>() { 8,2,1,1,2,2,3,4,5};
            ds5.Remove(1);
            Console.WriteLine("\nDanh sách 5 là: ");
            foreach(int i in ds5)
            {
                Console.Write(i + " ");
            }
            Console.WriteLine();
            // Count : Đếm số phần tử trong danh sách 
            List<int> ds6 = new List<int>() { 8, 2, 1, 1, 2, 2, 3, 4, 5 };
            Console.WriteLine(ds6.Count);

            // Clear : Xóa toàn bộ phần tử 
            List<int> ds7 = new List<int>() { 8, 2, 1, 1, 2, 2, 3, 4, 5 };
            ds7.Clear();

            // AddRange : Thêm toàn bộ danh sách 9 vào cuối dánh sách 8
            List<int> ds8 = new List<int>() { 8, 2, 1 };
            List<int> ds9 = new List<int>() { 100, 200};
            ds8.AddRange(ds9);
            Console.WriteLine("Danh sách 8 là: ");
            foreach (int i in ds8)
            {
                Console.Write(i +" ");
            }
            Console.WriteLine();
            // bool <ds> Contains <Value>
            List<int> ds10 = new List<int>() { 100,200 };
            bool kq = ds10 .Contains(100);
            Console.WriteLine(kq);

            // GetRange
            List<int> ds11 = new List<int>() { 100, 200, 1,5,6,9};
            List<int> ds12 = ds11.GetRange(1, 3);
            Console.WriteLine("Danh sách 12 là: ");
            foreach (int i in ds12)
            {
                Console.Write(i+" ");
            }
            Console.WriteLine();

            // int IndexOf<Value>
            List<int> ds13 = new List<int>() { 100, 200, 1, 5, 6, 9 };
            int checkIndex = ds13.IndexOf(200);
            Console.WriteLine(checkIndex);

            // Insert
            List<int> ds15 = new List<int>() { 100, 200, 1, 5, 6, 9 };
            ds15 .Insert(1, 1000);
            Console.WriteLine("Danh sách 15 là: ");
            foreach (int i in ds15)
            {
                Console.Write(i + " ");
            }
            Console.WriteLine();
            // InsertRange
            List<int> ds16 = new List<int>() { 100, 200, 1, 5, 6, 9 };
            List<int> ds17 = new List<int>() {  5, 9 };
            ds16.InsertRange(2, ds17);
            Console.WriteLine("Danh sách 16 là: ");
            foreach (int i in ds16)
            {
                Console.Write(i + " ");
            }
            Console.WriteLine();
            // RemoveAt 
            List<int> ds18 = new List<int>() { 100, 200, 1, 5, 6, 9 };
            ds18.RemoveAt(1);
            Console.WriteLine("Danh sách 18 là: ");
            foreach (int i in ds18)
            {
                Console.Write(i + " ");
            }
            Console.WriteLine();
            // RemoveRange
            List<int> ds19 = new List<int>() { 100, 200, 1, 5, 6, 9 };
            ds19.RemoveRange(1, 2);
            Console.WriteLine("Danh sách 19 là: ");
            foreach (int i in ds19)
            {
                Console.Write(i + " ");
            }
            Console.WriteLine();
            // Reverse Đảo ngược
            List<int> ds20 = new List<int>() { 100, 200, 1, 5, 6, 9 };
            ds20.Reverse();
            Console.WriteLine("Danh sách 20 là: ");
            foreach (int i in ds20)
            {
                Console.Write(i + " ");
            }
            Console.WriteLine();

            // .Sort Sắp xếp tăng dần
            List<int> ds21 = new List<int>() { 100, 200, 1, 5, 6, 9 };
            ds21.Sort();
            Console.WriteLine("Danh sách 21 là: ");
            foreach (int i in ds21)
            {
                Console.Write(i + " ");
            }
            Console.WriteLine();

            // BinarySertch 
            int kq2 = ds21.BinarySearch(200);
            Console.WriteLine(kq2);
            // Max, Min
            int kq3 = ds21.Max();
            Console.WriteLine(kq3);
            Console.WriteLine(ds21.Min());


            Console.ReadLine();
        }
    }
}
