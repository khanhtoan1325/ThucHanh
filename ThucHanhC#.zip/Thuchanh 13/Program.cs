﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Thuchanh_13
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Dictionary<string,string> dic = new Dictionary<string,string>();
            dic.Add("user 1", "123456");
            dic.Add("user 2", "123456");
            dic.Add("user 3", "123456");
            dic.Add("user 4", "123456");
            dic.Add("user 5", "123456");
            //Duyệt Dic
            foreach (KeyValuePair<string,string> pair in dic)
            {
                Console.WriteLine(pair);
            }
            Console.WriteLine("Mời nhập vào user name: ");
            string user = Console.ReadLine();
            Console.WriteLine("Mời nhập vào mật khẩu: ");
            string mk = Console.ReadLine();

            // Check user có tồn tại hay không 
            if (dic.ContainsKey(user) == false)
            {
                Console.WriteLine("User không tồn tại.");
            } 
            else
            {
                if (dic[user] == mk )
                {
                    Console.WriteLine("Đăng nhập thành công."); 
                }  
                else
                {
                    Console.WriteLine("Sai mật khẩu.");
                }    
            }    



            Console.ReadKey();



        }
    }
}
